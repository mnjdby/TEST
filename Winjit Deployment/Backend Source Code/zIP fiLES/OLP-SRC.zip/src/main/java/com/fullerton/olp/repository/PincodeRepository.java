package com.fullerton.olp.repository;

import com.fullerton.olp.model.Pincode;

//@Repository
public interface PincodeRepository extends GenericDao<Pincode, Long> {

}