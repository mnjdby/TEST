package com.fullerton.olp.repository;

import com.fullerton.olp.model.Company;
import com.fullerton.olp.repository.GenericDao;

//@Repository
public interface CompanyRepository extends GenericDao<Company, Long> {

}