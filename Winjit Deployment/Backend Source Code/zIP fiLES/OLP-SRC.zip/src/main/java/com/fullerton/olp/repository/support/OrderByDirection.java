package com.fullerton.olp.repository.support;

public enum OrderByDirection {
    ASC, DESC;
}
