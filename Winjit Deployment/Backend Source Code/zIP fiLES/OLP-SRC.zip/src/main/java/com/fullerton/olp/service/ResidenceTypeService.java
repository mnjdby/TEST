package com.fullerton.olp.service;

import com.fullerton.olp.model.ResidenceType;

public interface ResidenceTypeService extends GenericEntityService<ResidenceType, Long>{

}
