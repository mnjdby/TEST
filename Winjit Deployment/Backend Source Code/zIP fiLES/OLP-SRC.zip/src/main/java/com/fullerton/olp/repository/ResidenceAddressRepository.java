package com.fullerton.olp.repository;

import com.fullerton.olp.model.ResidenceAddress;
import com.fullerton.olp.repository.GenericDao;

//@Repository
public interface ResidenceAddressRepository extends GenericDao<ResidenceAddress, Long> {

}