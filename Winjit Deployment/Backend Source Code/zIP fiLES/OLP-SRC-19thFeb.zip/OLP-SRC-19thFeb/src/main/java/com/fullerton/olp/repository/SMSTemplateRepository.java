/**
 * 
 */
package com.fullerton.olp.repository;

import com.fullerton.olp.model.SMSTemplate;

/**
 * @author saurabh.shastri
 *
 */
public interface SMSTemplateRepository extends GenericDao<SMSTemplate, Long> {

}
