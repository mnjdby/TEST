package com.fullerton.olp.repository;

import com.fullerton.olp.model.Territory;
import com.fullerton.olp.repository.GenericDao;

//@Repository
public interface TerritoryRepository extends GenericDao<Territory, Long> {

}