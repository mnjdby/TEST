package com.fullerton.olp.repository;

import com.fullerton.olp.model.Profession;
import com.fullerton.olp.repository.GenericDao;

//@Repository
public interface ProfessionRepository extends GenericDao<Profession, Long> {

}