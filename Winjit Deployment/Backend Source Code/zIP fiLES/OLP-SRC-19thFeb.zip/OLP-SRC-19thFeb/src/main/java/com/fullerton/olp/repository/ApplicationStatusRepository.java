/**
 * 
 */
package com.fullerton.olp.repository;

import com.fullerton.olp.model.ApplicationStatus;

/**
 * @author Nitish
 *
 */
public interface ApplicationStatusRepository extends GenericDao<ApplicationStatus, Long> {

}
