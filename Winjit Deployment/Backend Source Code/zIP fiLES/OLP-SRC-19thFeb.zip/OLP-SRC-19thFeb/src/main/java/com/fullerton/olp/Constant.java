package com.fullerton.olp;

public abstract class Constant {
	public final static Integer PAGE_SIZE = 10;
}
