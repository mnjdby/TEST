package com.fullerton.olp.repository;

import com.fullerton.olp.model.State;
import com.fullerton.olp.repository.GenericDao;

//@Repository
public interface StateRepository extends GenericDao<State, Long> {

}