package com.fullerton.olp.repository;

import com.fullerton.olp.model.DocumentType;

//@Repository
public interface DocumentTypeRepository extends GenericDao<DocumentType, Long> {

}