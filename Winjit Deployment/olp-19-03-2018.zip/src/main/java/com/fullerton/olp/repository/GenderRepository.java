package com.fullerton.olp.repository;

import com.fullerton.olp.model.Gender;
import com.fullerton.olp.repository.GenericDao;

//@Repository
public interface GenderRepository extends GenericDao<Gender, Long> {

}