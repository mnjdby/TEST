package com.fullerton.olp.repository;

import com.fullerton.olp.model.Qualification;
import com.fullerton.olp.repository.GenericDao;

//@Repository
public interface QualificationRepository extends GenericDao<Qualification, Long> {

}