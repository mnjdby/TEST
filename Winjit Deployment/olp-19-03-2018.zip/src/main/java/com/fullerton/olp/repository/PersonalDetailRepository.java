package com.fullerton.olp.repository;

import com.fullerton.olp.model.PersonalDetail;
import com.fullerton.olp.repository.GenericDao;

//@Repository
public interface PersonalDetailRepository extends GenericDao<PersonalDetail, Long> {

}