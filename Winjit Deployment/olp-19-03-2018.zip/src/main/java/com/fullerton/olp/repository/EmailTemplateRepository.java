/**
 * 
 */
package com.fullerton.olp.repository;

import com.fullerton.olp.model.EmailTemplate;

/**
 * @author saurabh.shastri
 *
 */
public interface EmailTemplateRepository extends GenericDao<EmailTemplate, Long> {

}
