package com.fullerton.olp.repository;

import com.fullerton.olp.model.Document;

//@Repository
public interface DocumentRepository extends GenericDao<Document, Long> {

}