package com.fullerton.olp.settings.exceptions;

public class StatusPendingException  extends RuntimeException {

}
