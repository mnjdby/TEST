package com.fullerton.olp.repository.support;

import java.util.List;

/**
 * Convenient named query manipulation class.
 */
public interface NamedQueryUtil {
    /**
     * Returns a list given a named query
     *
     * @param searchTemplate the searchTemplate with the namedQuery property set.
     * @return the resulting collection
     */
    List<? extends Object> findByNamedQuery(SearchTemplate searchTemplate);

    /**
     * return a collection given a named query and parameters
     *
     * @param searchTemplate the searchTemplate with the namedQuery property set.
     * @param model value bean object
     * @return the resulting collection
     */
    List<? extends Object> findByNamedQuery(SearchTemplate searchTemplate, Object model);

    /**
     * Returns a number given a named query.
     *
     * @param searchTemplate the searchTemplate with the namedQuery property set.
     * @return the resulting number
     */
    Number numberByNamedQuery(SearchTemplate searchTemplate);

    /**
     * Return a Number given a named query and a sample.
     *
     * @param searchTemplate the searchTemplate with the namedQuery property set.
     * @param sample
     * @return the resulting number
     */
    Number numberByNamedQuery(SearchTemplate searchTemplate, Object sample);

    /**
     * Returns an arbitrary object given a named query
     *
     * @param searchTemplate the searchTemplate with the namedQuery property set.
     * @return the resulting object, it can be a list or any type given your named query definition.
     */
    Object objectByNamedQuery(SearchTemplate searchTemplate);

    /**
     * Returns an arbitrary object given a named query and parameters
     *
     * @param searchTemplate the searchTemplate with the namedQuery property set.
     * @param model a value bean to be used
     * @return the resulting object, it can be a collection or any type given your named query definition
     */
    Object objectByNamedQuery(SearchTemplate searchTemplate, Object model);
}
