package com.fullerton.olp.repository;

import com.fullerton.olp.model.AuditTrail;

//@Repository
public interface AuditTrailRepository extends GenericDao<AuditTrail, Long> {

}