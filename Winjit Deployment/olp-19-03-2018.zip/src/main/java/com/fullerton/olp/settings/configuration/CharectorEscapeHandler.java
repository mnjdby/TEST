package com.fullerton.olp.settings.configuration;

public class CharectorEscapeHandler {

}
