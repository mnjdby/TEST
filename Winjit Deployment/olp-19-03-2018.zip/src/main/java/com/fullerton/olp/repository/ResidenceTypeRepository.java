package com.fullerton.olp.repository;

import com.fullerton.olp.model.ResidenceType;

//@Repository
public interface ResidenceTypeRepository extends GenericDao<ResidenceType, Long> {

}