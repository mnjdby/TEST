package com.fullerton.olp.repository;

import com.fullerton.olp.model.ProfessionalDetail;
import com.fullerton.olp.repository.GenericDao;

//@Repository
public interface ProfessionalDetailRepository extends GenericDao<ProfessionalDetail, Long> {

}